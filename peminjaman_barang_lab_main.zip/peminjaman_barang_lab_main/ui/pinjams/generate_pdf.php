<?php
require('../../fpdf/fpdf.php');
include '../../config/config.php';

//vFormat Tanggal Indo
function formatTanggal($tanggal) {
    setlocale(LC_TIME, 'id_ID.utf8');
    return strftime('%d %B %Y', strtotime($tanggal));
}

// Ambil URL FILTER
$tgl_pinjam = isset($_GET['tgl_pinjam']) ? $_GET['tgl_pinjam'] : '';
$tgl_kembali = isset($_GET['tgl_kembali']) ? $_GET['tgl_kembali'] : '';

// Query peminjaman dengan filter tanggal
$sql_peminjaman = "SELECT pinjams.id, user.nama, items.nama_barang, pinjams.jumlah, pinjams.tgl_peminjaman, pinjams.tgl_pengembalian, pinjams.status 
                   FROM pinjams 
                   INNER JOIN user ON pinjams.users_id = user.id 
                   INNER JOIN items ON pinjams.items_id = items.id
                   WHERE 1=1";

// Tambahkan filter untuk tanggal peminjaman
if ($tgl_pinjam) {
    $sql_peminjaman .= " AND pinjams.tgl_peminjaman >= '$tgl_pinjam'";
}

// Tambahkan filter untuk tanggal pengembalian
if ($tgl_kembali) {
    $sql_peminjaman .= " AND pinjams.tgl_pengembalian <= '$tgl_kembali'";
}

$query_peminjaman = mysqli_query($conn, $sql_peminjaman);

// Membuat instance FPDF
$pdf = new FPDF();
$pdf->AddPage();

// Menetapkan margin kertas (10mm kiri dan kanan, 10mm atas dan bawah)
$pdf->SetMargins(10, 10, 10);
$pdf->SetAutoPageBreak(true, 10);  // Margin bawah ditetapkan 10mm

// Atur font untuk judul
$pdf->SetFont('Arial', 'B', 12);

// Judul
$pdf->Cell(0, 10, 'Rekap Peminjaman Barang SMKN 11 Malang', 0, 1, 'C');

// Spasi setelah judul
$pdf->Ln(5);

// Tambahkan keterangan tanggal di bawah judul
$pdf->SetFont('Arial', '', 10);

// Jika Tanggal Pinjam di-set
if ($tgl_pinjam) {
    $pdf->Cell(0, 10, 'Tanggal Pinjam: ' . formatTanggal($tgl_pinjam), 0, 1, 'C');
} else {
    $pdf->Cell(0, 10, 'Tanggal Pinjam: Tidak Ditentukan', 0, 1, 'C');
}

// Jika Tanggal Kembali di-set
if ($tgl_kembali) {
    $pdf->Cell(0, 10, 'Tanggal Kembali: ' . formatTanggal($tgl_kembali), 0, 1, 'C');
} else {
    $pdf->Cell(0, 10, 'Tanggal Kembali: Tidak Ditentukan', 0, 1, 'C');
}

// Spasi setelah keterangan tanggal
$pdf->Ln(5);

// Tabel header
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 10, 'NO', 1);
$pdf->Cell(35, 10, 'Peminjam', 1);
$pdf->Cell(35, 10, 'Nama Barang', 1);
$pdf->Cell(20, 10, 'Jumlah', 1);
$pdf->Cell(30, 10, 'Tgl Pinjam', 1);
$pdf->Cell(30, 10, 'Tgl Kembali', 1);
$pdf->Cell(30, 10, 'Status', 1);
$pdf->Ln();

// Isi tabel
$pdf->SetFont('Arial', '', 10);

$no_urut = 1;
while ($pinjam = mysqli_fetch_array($query_peminjaman)) {
    $pdf->Cell(10, 10, $no_urut, 1);  
    $pdf->Cell(35, 10, $pinjam['nama'], 1);
    $pdf->Cell(35, 10, $pinjam['nama_barang'], 1);
    $pdf->Cell(20, 10, $pinjam['jumlah'], 1);
    $pdf->Cell(30, 10, $pinjam['tgl_peminjaman'], 1);
    $pdf->Cell(30, 10, ($pinjam['tgl_pengembalian'] ? $pinjam['tgl_pengembalian'] : 'Belum dikembalikan'), 1);
    $pdf->Cell(30, 10, ($pinjam['status'] == 'dipinjam' ? 'Dipinjam' : 'Dikembalikan'), 1);
    $pdf->Ln();

    $no_urut++;
}

// Output file PDF langsung ke browser
$pdf->Output();
?>
